# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'gen3release'}

packages = \
['config', 'filesys', 'gith']

package_data = \
{'': ['*']}

modules = \
['env_cli']
install_requires = \
['PyGitHub>=1.47,<2.0']

entry_points = \
{'console_scripts': ['gen3release = gen3release.env_cli:main']}

setup_kwargs = {
    'name': 'gen3release',
    'version': '0.2.22',
    'description': 'Gen3 Release Management SDK',
    'long_description': None,
    'author': 'CTDS UChicago',
    'author_email': 'cdis@uchicago.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
